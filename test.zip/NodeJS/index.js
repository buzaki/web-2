/*
Write a function that checks whether a given number exists in a list.
If the number exists,
returns True if that number is the largest element in a list,
otherwise return False
 */
const testList = [2,3,3,5,67,82,13,5,67,123,6,12,6,12,3];

function isNumberExistsOnlist(number,list) {
    // check if the number exists on the list or not ?!
    const isNumberExists = list.indexOf(number) > -1;
    if (isNumberExists) {
        // get the largest number of the list.
        const largestNumberOnTheList = Math.max.apply(null,list);
        // check if the number in equal to largest number or not and return.
        return largestNumberOnTheList === number;

    }
    // mean that number doesn't match any case above.
    return false;
}

console.log(isNumberExistsOnlist(2,testList));



