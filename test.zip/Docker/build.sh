#!/bin/bash
docker build -t html .
docker run -p 8888:80 -d html
echo " docker is running on port : 8888 "

